'''
python的while与if条件分支类似，不同的是，只要条件为真，while循环就会一直重复一段代码，这段代码为循环体
while 条件:
    循环体

请下面将打印1+2+3+4……+100的结果
'''

i = 1
sum = 0
while i <= 100:
    sum += i
    i += 1
print(sum)

