'''
单行注释： # 
多行注释：
'''


for i in range(10):
    # print(i)
    print('0')


a = '我不爱做作业'
b = '我不爱学习'
print(a + b)