a = 0
if a == 0:
    print("hello",end="")
print("hello")