import random

anwser = random.randint(1, 100)

num1 = eval(input("请输入第一个数字"))
num2 = eval(input("请输入第二个数字"))

print("{} + {} = {}".format(num1, num2, anwser))
