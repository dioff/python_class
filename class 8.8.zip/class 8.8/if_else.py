# a = eval(input())
# if a == 0:
#     print("yes")
#     print("yes")
#     print("yes")
#     print("yes")
#     print("yes")
#     print("yes")
# else:
#     print("no")

"""
    Tab按键的作用：缩进
    缩进是python的灵魂：
    Python是一门独特的语言，
    它的代码块是通过缩进（Indentation）来标记的（大部分语言都是使用花括号作为代码块的标记），具有相同缩进的多行代码属于同一个代码块。
    Python中的缩进（Indentation）决定了代码的作用域范围。
"""


"""
if 条件：
    条件为真(True)执行操作
else:
    条件为假(Fasle)执行的操作
"""
a = 1
if 1 == 1:
    print('1 + 1 = 3')
else:
    print('1 + 1 = 4')

