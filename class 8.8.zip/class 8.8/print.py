# name = input("请输入你的名字：")
# print("欢迎{}的到来".format(name))

# print("你好" + "我是TIM")
# print(1+1)
# print("Hello {}, welcome to my class".format("JAN"))

# 下面这个会发生什么
print("I love python\n"  * 3)
# 既然可以做乘法，那么我们可以做加法吗

# print("I love python\n" + 3)
# 字符串的拼接用加法 加法，让两个东东拼接起来的话，那要保证两边都是字符串，不能一边字符串一边数字