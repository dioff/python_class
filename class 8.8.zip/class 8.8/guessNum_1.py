"""第一个小游戏"""
guess = eval(input("猜一猜我现在心里想的数字1-9之内"))
if guess == 8:
    print("猜对了你怎么知道我心里所想的呢")
else:
    print("猜错了，我现在心里想的是8")
print("游戏结束了，不玩咯！")