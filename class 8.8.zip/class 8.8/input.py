# a = input("请输入")
# print(a)


# 我们再做一个小游戏，来计算成本
"""假设我们有许多的蛋糕，蛋糕的成本为10元，现在请设计一个程序，使得输入蛋糕的售价可以自动计算利润"""
# price = input("蛋糕的售价是多少")
# # cost = 10
# # print("成本为：{}".format(price - 10))

# print(type(price))

# price = int(input("蛋糕的售价是多少"))
price1 = eval(input("蛋糕的售价为多少"))
cost = 15
# print(type(price))
print("利润为：{}".format(price1 - cost))





